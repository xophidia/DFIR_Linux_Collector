/* This is a generated file, don't edit */

#define NUM_APPLETS 399
#define KNOWN_APPNAME_OFFSETS 8

const uint16_t applet_nameofs[] ALIGN2 = {
305,
655,
999,
1334,
1689,
2080,
2407,
};

const char applet_names[] ALIGN1 = ""
"[" "\0"
"[[" "\0"
"acpid" "\0"
"add-shell" "\0"
"addgroup" "\0"
"adduser" "\0"
"adjtimex" "\0"
"arch" "\0"
"arp" "\0"
"arping" "\0"
"ascii" "\0"
"ash" "\0"
"awk" "\0"
"base32" "\0"
"base64" "\0"
"basename" "\0"
"bc" "\0"
"beep" "\0"
"blkdiscard" "\0"
"blkid" "\0"
"blockdev" "\0"
"bootchartd" "\0"
"brctl" "\0"
"bunzip2" "\0"
"bzcat" "\0"
"bzip2" "\0"
"cal" "\0"
"cat" "\0"
"chat" "\0"
"chattr" "\0"
"chgrp" "\0"
"chmod" "\0"
"chown" "\0"
"chpasswd" "\0"
"chpst" "\0"
"chroot" "\0"
"chrt" "\0"
"chvt" "\0"
"cksum" "\0"
"clear" "\0"
"cmp" "\0"
"comm" "\0"
"conspy" "\0"
"cp" "\0"
"cpio" "\0"
"crc32" "\0"
"crond" "\0"
"crontab" "\0"
"cryptpw" "\0"
"cttyhack" "\0"
"cut" "\0"
"date" "\0"
"dc" "\0"
"dd" "\0"
"deallocvt" "\0"
"delgroup" "\0"
"deluser" "\0"
"depmod" "\0"
"devmem" "\0"
"df" "\0"
"dhcprelay" "\0"
"diff" "\0"
"dirname" "\0"
"dmesg" "\0"
"dnsd" "\0"
"dnsdomainname" "\0"
"dos2unix" "\0"
"dpkg" "\0"
"dpkg-deb" "\0"
"du" "\0"
"dumpkmap" "\0"
"dumpleases" "\0"
"echo" "\0"
"ed" "\0"
"egrep" "\0"
"eject" "\0"
"env" "\0"
"envdir" "\0"
"envuidgid" "\0"
"ether-wake" "\0"
"expand" "\0"
"expr" "\0"
"factor" "\0"
"fakeidentd" "\0"
"fallocate" "\0"
"false" "\0"
"fatattr" "\0"
"fbset" "\0"
"fbsplash" "\0"
"fdflush" "\0"
"fdformat" "\0"
"fdisk" "\0"
"fgconsole" "\0"
"fgrep" "\0"
"find" "\0"
"findfs" "\0"
"flock" "\0"
"fold" "\0"
"free" "\0"
"freeramdisk" "\0"
"fsck" "\0"
"fsck.minix" "\0"
"fsfreeze" "\0"
"fstrim" "\0"
"fsync" "\0"
"ftpd" "\0"
"ftpget" "\0"
"ftpput" "\0"
"fuser" "\0"
"getopt" "\0"
"getty" "\0"
"grep" "\0"
"groups" "\0"
"gunzip" "\0"
"gzip" "\0"
"halt" "\0"
"hd" "\0"
"hdparm" "\0"
"head" "\0"
"hexdump" "\0"
"hexedit" "\0"
"hostid" "\0"
"hostname" "\0"
"httpd" "\0"
"hush" "\0"
"hwclock" "\0"
"i2cdetect" "\0"
"i2cdump" "\0"
"i2cget" "\0"
"i2cset" "\0"
"i2ctransfer" "\0"
"id" "\0"
"ifconfig" "\0"
"ifdown" "\0"
"ifenslave" "\0"
"ifplugd" "\0"
"ifup" "\0"
"inetd" "\0"
"init" "\0"
"insmod" "\0"
"install" "\0"
"ionice" "\0"
"iostat" "\0"
"ip" "\0"
"ipaddr" "\0"
"ipcalc" "\0"
"ipcrm" "\0"
"ipcs" "\0"
"iplink" "\0"
"ipneigh" "\0"
"iproute" "\0"
"iprule" "\0"
"iptunnel" "\0"
"kbd_mode" "\0"
"kill" "\0"
"killall" "\0"
"killall5" "\0"
"klogd" "\0"
"last" "\0"
"less" "\0"
"link" "\0"
"linux32" "\0"
"linux64" "\0"
"linuxrc" "\0"
"ln" "\0"
"loadfont" "\0"
"loadkmap" "\0"
"logger" "\0"
"login" "\0"
"logname" "\0"
"logread" "\0"
"losetup" "\0"
"lpd" "\0"
"lpq" "\0"
"lpr" "\0"
"ls" "\0"
"lsattr" "\0"
"lsmod" "\0"
"lsof" "\0"
"lspci" "\0"
"lsscsi" "\0"
"lsusb" "\0"
"lzcat" "\0"
"lzma" "\0"
"lzop" "\0"
"makedevs" "\0"
"makemime" "\0"
"man" "\0"
"md5sum" "\0"
"mdev" "\0"
"mesg" "\0"
"microcom" "\0"
"mim" "\0"
"mkdir" "\0"
"mkdosfs" "\0"
"mke2fs" "\0"
"mkfifo" "\0"
"mkfs.ext2" "\0"
"mkfs.minix" "\0"
"mkfs.vfat" "\0"
"mknod" "\0"
"mkpasswd" "\0"
"mkswap" "\0"
"mktemp" "\0"
"modinfo" "\0"
"modprobe" "\0"
"more" "\0"
"mount" "\0"
"mountpoint" "\0"
"mpstat" "\0"
"mt" "\0"
"mv" "\0"
"nameif" "\0"
"nanddump" "\0"
"nandwrite" "\0"
"nbd-client" "\0"
"nc" "\0"
"netstat" "\0"
"nice" "\0"
"nl" "\0"
"nmeter" "\0"
"nohup" "\0"
"nologin" "\0"
"nproc" "\0"
"nsenter" "\0"
"nslookup" "\0"
"ntpd" "\0"
"od" "\0"
"openvt" "\0"
"partprobe" "\0"
"passwd" "\0"
"paste" "\0"
"patch" "\0"
"pgrep" "\0"
"pidof" "\0"
"ping" "\0"
"ping6" "\0"
"pipe_progress" "\0"
"pivot_root" "\0"
"pkill" "\0"
"pmap" "\0"
"popmaildir" "\0"
"poweroff" "\0"
"powertop" "\0"
"printenv" "\0"
"printf" "\0"
"ps" "\0"
"pscan" "\0"
"pstree" "\0"
"pwd" "\0"
"pwdx" "\0"
"raidautorun" "\0"
"rdate" "\0"
"rdev" "\0"
"readahead" "\0"
"readlink" "\0"
"readprofile" "\0"
"realpath" "\0"
"reboot" "\0"
"reformime" "\0"
"remove-shell" "\0"
"renice" "\0"
"reset" "\0"
"resize" "\0"
"resume" "\0"
"rev" "\0"
"rm" "\0"
"rmdir" "\0"
"rmmod" "\0"
"route" "\0"
"rpm" "\0"
"rpm2cpio" "\0"
"rtcwake" "\0"
"run-init" "\0"
"run-parts" "\0"
"runlevel" "\0"
"runsv" "\0"
"runsvdir" "\0"
"rx" "\0"
"script" "\0"
"scriptreplay" "\0"
"sed" "\0"
"sendmail" "\0"
"seq" "\0"
"setarch" "\0"
"setconsole" "\0"
"setfattr" "\0"
"setfont" "\0"
"setkeycodes" "\0"
"setlogcons" "\0"
"setpriv" "\0"
"setserial" "\0"
"setsid" "\0"
"setuidgid" "\0"
"sh" "\0"
"sha1sum" "\0"
"sha256sum" "\0"
"sha3sum" "\0"
"sha512sum" "\0"
"showkey" "\0"
"shred" "\0"
"shuf" "\0"
"slattach" "\0"
"sleep" "\0"
"smemcap" "\0"
"softlimit" "\0"
"sort" "\0"
"split" "\0"
"ssl_client" "\0"
"start-stop-daemon" "\0"
"stat" "\0"
"strings" "\0"
"stty" "\0"
"su" "\0"
"sulogin" "\0"
"sum" "\0"
"sv" "\0"
"svc" "\0"
"svlogd" "\0"
"svok" "\0"
"swapoff" "\0"
"swapon" "\0"
"switch_root" "\0"
"sync" "\0"
"sysctl" "\0"
"syslogd" "\0"
"tac" "\0"
"tail" "\0"
"tar" "\0"
"taskset" "\0"
"tc" "\0"
"tcpsvd" "\0"
"tee" "\0"
"telnet" "\0"
"telnetd" "\0"
"test" "\0"
"tftp" "\0"
"tftpd" "\0"
"time" "\0"
"timeout" "\0"
"top" "\0"
"touch" "\0"
"tr" "\0"
"traceroute" "\0"
"traceroute6" "\0"
"true" "\0"
"truncate" "\0"
"ts" "\0"
"tty" "\0"
"ttysize" "\0"
"tunctl" "\0"
"ubiattach" "\0"
"ubidetach" "\0"
"ubimkvol" "\0"
"ubirename" "\0"
"ubirmvol" "\0"
"ubirsvol" "\0"
"ubiupdatevol" "\0"
"udhcpc" "\0"
"udhcpc6" "\0"
"udhcpd" "\0"
"udpsvd" "\0"
"uevent" "\0"
"umount" "\0"
"uname" "\0"
"unexpand" "\0"
"uniq" "\0"
"unix2dos" "\0"
"unlink" "\0"
"unlzma" "\0"
"unshare" "\0"
"unxz" "\0"
"unzip" "\0"
"uptime" "\0"
"users" "\0"
"usleep" "\0"
"uudecode" "\0"
"uuencode" "\0"
"vconfig" "\0"
"vi" "\0"
"vlock" "\0"
"volname" "\0"
"w" "\0"
"wall" "\0"
"watch" "\0"
"watchdog" "\0"
"wc" "\0"
"wget" "\0"
"which" "\0"
"who" "\0"
"whoami" "\0"
"whois" "\0"
"xargs" "\0"
"xxd" "\0"
"xz" "\0"
"xzcat" "\0"
"yes" "\0"
"zcat" "\0"
"zcip" "\0"
;

#define APPLET_NO_acpid 2
#define APPLET_NO_addgroup 4
#define APPLET_NO_adduser 5
#define APPLET_NO_adjtimex 6
#define APPLET_NO_arch 7
#define APPLET_NO_arp 8
#define APPLET_NO_arping 9
#define APPLET_NO_ascii 10
#define APPLET_NO_ash 11
#define APPLET_NO_awk 12
#define APPLET_NO_base32 13
#define APPLET_NO_base64 14
#define APPLET_NO_basename 15
#define APPLET_NO_bc 16
#define APPLET_NO_beep 17
#define APPLET_NO_blkdiscard 18
#define APPLET_NO_blkid 19
#define APPLET_NO_blockdev 20
#define APPLET_NO_bootchartd 21
#define APPLET_NO_brctl 22
#define APPLET_NO_bunzip2 23
#define APPLET_NO_bzcat 24
#define APPLET_NO_bzip2 25
#define APPLET_NO_cal 26
#define APPLET_NO_cat 27
#define APPLET_NO_chat 28
#define APPLET_NO_chattr 29
#define APPLET_NO_chgrp 30
#define APPLET_NO_chmod 31
#define APPLET_NO_chown 32
#define APPLET_NO_chpasswd 33
#define APPLET_NO_chpst 34
#define APPLET_NO_chroot 35
#define APPLET_NO_chrt 36
#define APPLET_NO_chvt 37
#define APPLET_NO_cksum 38
#define APPLET_NO_clear 39
#define APPLET_NO_cmp 40
#define APPLET_NO_comm 41
#define APPLET_NO_conspy 42
#define APPLET_NO_cp 43
#define APPLET_NO_cpio 44
#define APPLET_NO_crc32 45
#define APPLET_NO_crond 46
#define APPLET_NO_crontab 47
#define APPLET_NO_cryptpw 48
#define APPLET_NO_cttyhack 49
#define APPLET_NO_cut 50
#define APPLET_NO_date 51
#define APPLET_NO_dc 52
#define APPLET_NO_dd 53
#define APPLET_NO_deallocvt 54
#define APPLET_NO_delgroup 55
#define APPLET_NO_deluser 56
#define APPLET_NO_depmod 57
#define APPLET_NO_devmem 58
#define APPLET_NO_df 59
#define APPLET_NO_dhcprelay 60
#define APPLET_NO_diff 61
#define APPLET_NO_dirname 62
#define APPLET_NO_dmesg 63
#define APPLET_NO_dnsd 64
#define APPLET_NO_dnsdomainname 65
#define APPLET_NO_dos2unix 66
#define APPLET_NO_dpkg 67
#define APPLET_NO_du 69
#define APPLET_NO_dumpkmap 70
#define APPLET_NO_dumpleases 71
#define APPLET_NO_echo 72
#define APPLET_NO_ed 73
#define APPLET_NO_egrep 74
#define APPLET_NO_eject 75
#define APPLET_NO_env 76
#define APPLET_NO_envdir 77
#define APPLET_NO_envuidgid 78
#define APPLET_NO_expand 80
#define APPLET_NO_expr 81
#define APPLET_NO_factor 82
#define APPLET_NO_fakeidentd 83
#define APPLET_NO_fallocate 84
#define APPLET_NO_false 85
#define APPLET_NO_fatattr 86
#define APPLET_NO_fbset 87
#define APPLET_NO_fbsplash 88
#define APPLET_NO_fdflush 89
#define APPLET_NO_fdformat 90
#define APPLET_NO_fdisk 91
#define APPLET_NO_fgconsole 92
#define APPLET_NO_fgrep 93
#define APPLET_NO_find 94
#define APPLET_NO_findfs 95
#define APPLET_NO_flock 96
#define APPLET_NO_fold 97
#define APPLET_NO_free 98
#define APPLET_NO_freeramdisk 99
#define APPLET_NO_fsck 100
#define APPLET_NO_fsfreeze 102
#define APPLET_NO_fstrim 103
#define APPLET_NO_fsync 104
#define APPLET_NO_ftpd 105
#define APPLET_NO_ftpget 106
#define APPLET_NO_ftpput 107
#define APPLET_NO_fuser 108
#define APPLET_NO_getopt 109
#define APPLET_NO_getty 110
#define APPLET_NO_grep 111
#define APPLET_NO_groups 112
#define APPLET_NO_gunzip 113
#define APPLET_NO_gzip 114
#define APPLET_NO_halt 115
#define APPLET_NO_hd 116
#define APPLET_NO_hdparm 117
#define APPLET_NO_head 118
#define APPLET_NO_hexdump 119
#define APPLET_NO_hexedit 120
#define APPLET_NO_hostid 121
#define APPLET_NO_hostname 122
#define APPLET_NO_httpd 123
#define APPLET_NO_hush 124
#define APPLET_NO_hwclock 125
#define APPLET_NO_i2cdetect 126
#define APPLET_NO_i2cdump 127
#define APPLET_NO_i2cget 128
#define APPLET_NO_i2cset 129
#define APPLET_NO_i2ctransfer 130
#define APPLET_NO_id 131
#define APPLET_NO_ifconfig 132
#define APPLET_NO_ifdown 133
#define APPLET_NO_ifenslave 134
#define APPLET_NO_ifplugd 135
#define APPLET_NO_ifup 136
#define APPLET_NO_inetd 137
#define APPLET_NO_init 138
#define APPLET_NO_insmod 139
#define APPLET_NO_install 140
#define APPLET_NO_ionice 141
#define APPLET_NO_iostat 142
#define APPLET_NO_ip 143
#define APPLET_NO_ipaddr 144
#define APPLET_NO_ipcalc 145
#define APPLET_NO_ipcrm 146
#define APPLET_NO_ipcs 147
#define APPLET_NO_iplink 148
#define APPLET_NO_ipneigh 149
#define APPLET_NO_iproute 150
#define APPLET_NO_iprule 151
#define APPLET_NO_iptunnel 152
#define APPLET_NO_kbd_mode 153
#define APPLET_NO_kill 154
#define APPLET_NO_killall 155
#define APPLET_NO_killall5 156
#define APPLET_NO_klogd 157
#define APPLET_NO_last 158
#define APPLET_NO_less 159
#define APPLET_NO_link 160
#define APPLET_NO_linux32 161
#define APPLET_NO_linux64 162
#define APPLET_NO_linuxrc 163
#define APPLET_NO_ln 164
#define APPLET_NO_loadfont 165
#define APPLET_NO_loadkmap 166
#define APPLET_NO_logger 167
#define APPLET_NO_login 168
#define APPLET_NO_logname 169
#define APPLET_NO_logread 170
#define APPLET_NO_losetup 171
#define APPLET_NO_lpd 172
#define APPLET_NO_lpq 173
#define APPLET_NO_lpr 174
#define APPLET_NO_ls 175
#define APPLET_NO_lsattr 176
#define APPLET_NO_lsmod 177
#define APPLET_NO_lsof 178
#define APPLET_NO_lspci 179
#define APPLET_NO_lsscsi 180
#define APPLET_NO_lsusb 181
#define APPLET_NO_lzcat 182
#define APPLET_NO_lzma 183
#define APPLET_NO_lzop 184
#define APPLET_NO_makedevs 185
#define APPLET_NO_makemime 186
#define APPLET_NO_man 187
#define APPLET_NO_md5sum 188
#define APPLET_NO_mdev 189
#define APPLET_NO_mesg 190
#define APPLET_NO_microcom 191
#define APPLET_NO_mim 192
#define APPLET_NO_mkdir 193
#define APPLET_NO_mkdosfs 194
#define APPLET_NO_mke2fs 195
#define APPLET_NO_mkfifo 196
#define APPLET_NO_mknod 200
#define APPLET_NO_mkpasswd 201
#define APPLET_NO_mkswap 202
#define APPLET_NO_mktemp 203
#define APPLET_NO_modinfo 204
#define APPLET_NO_modprobe 205
#define APPLET_NO_more 206
#define APPLET_NO_mount 207
#define APPLET_NO_mountpoint 208
#define APPLET_NO_mpstat 209
#define APPLET_NO_mt 210
#define APPLET_NO_mv 211
#define APPLET_NO_nameif 212
#define APPLET_NO_nanddump 213
#define APPLET_NO_nandwrite 214
#define APPLET_NO_nc 216
#define APPLET_NO_netstat 217
#define APPLET_NO_nice 218
#define APPLET_NO_nl 219
#define APPLET_NO_nmeter 220
#define APPLET_NO_nohup 221
#define APPLET_NO_nologin 222
#define APPLET_NO_nproc 223
#define APPLET_NO_nsenter 224
#define APPLET_NO_nslookup 225
#define APPLET_NO_ntpd 226
#define APPLET_NO_od 227
#define APPLET_NO_openvt 228
#define APPLET_NO_partprobe 229
#define APPLET_NO_passwd 230
#define APPLET_NO_paste 231
#define APPLET_NO_patch 232
#define APPLET_NO_pgrep 233
#define APPLET_NO_pidof 234
#define APPLET_NO_ping 235
#define APPLET_NO_ping6 236
#define APPLET_NO_pipe_progress 237
#define APPLET_NO_pivot_root 238
#define APPLET_NO_pkill 239
#define APPLET_NO_pmap 240
#define APPLET_NO_popmaildir 241
#define APPLET_NO_poweroff 242
#define APPLET_NO_powertop 243
#define APPLET_NO_printenv 244
#define APPLET_NO_printf 245
#define APPLET_NO_ps 246
#define APPLET_NO_pscan 247
#define APPLET_NO_pstree 248
#define APPLET_NO_pwd 249
#define APPLET_NO_pwdx 250
#define APPLET_NO_raidautorun 251
#define APPLET_NO_rdate 252
#define APPLET_NO_rdev 253
#define APPLET_NO_readahead 254
#define APPLET_NO_readlink 255
#define APPLET_NO_readprofile 256
#define APPLET_NO_realpath 257
#define APPLET_NO_reboot 258
#define APPLET_NO_reformime 259
#define APPLET_NO_renice 261
#define APPLET_NO_reset 262
#define APPLET_NO_resize 263
#define APPLET_NO_resume 264
#define APPLET_NO_rev 265
#define APPLET_NO_rm 266
#define APPLET_NO_rmdir 267
#define APPLET_NO_rmmod 268
#define APPLET_NO_route 269
#define APPLET_NO_rpm 270
#define APPLET_NO_rpm2cpio 271
#define APPLET_NO_rtcwake 272
#define APPLET_NO_runlevel 275
#define APPLET_NO_runsv 276
#define APPLET_NO_runsvdir 277
#define APPLET_NO_rx 278
#define APPLET_NO_script 279
#define APPLET_NO_scriptreplay 280
#define APPLET_NO_sed 281
#define APPLET_NO_sendmail 282
#define APPLET_NO_seq 283
#define APPLET_NO_setarch 284
#define APPLET_NO_setconsole 285
#define APPLET_NO_setfattr 286
#define APPLET_NO_setfont 287
#define APPLET_NO_setkeycodes 288
#define APPLET_NO_setlogcons 289
#define APPLET_NO_setpriv 290
#define APPLET_NO_setserial 291
#define APPLET_NO_setsid 292
#define APPLET_NO_setuidgid 293
#define APPLET_NO_sh 294
#define APPLET_NO_sha1sum 295
#define APPLET_NO_sha256sum 296
#define APPLET_NO_sha3sum 297
#define APPLET_NO_sha512sum 298
#define APPLET_NO_showkey 299
#define APPLET_NO_shred 300
#define APPLET_NO_shuf 301
#define APPLET_NO_slattach 302
#define APPLET_NO_sleep 303
#define APPLET_NO_smemcap 304
#define APPLET_NO_softlimit 305
#define APPLET_NO_sort 306
#define APPLET_NO_split 307
#define APPLET_NO_ssl_client 308
#define APPLET_NO_stat 310
#define APPLET_NO_strings 311
#define APPLET_NO_stty 312
#define APPLET_NO_su 313
#define APPLET_NO_sulogin 314
#define APPLET_NO_sum 315
#define APPLET_NO_sv 316
#define APPLET_NO_svc 317
#define APPLET_NO_svlogd 318
#define APPLET_NO_svok 319
#define APPLET_NO_swapoff 320
#define APPLET_NO_swapon 321
#define APPLET_NO_switch_root 322
#define APPLET_NO_sync 323
#define APPLET_NO_sysctl 324
#define APPLET_NO_syslogd 325
#define APPLET_NO_tac 326
#define APPLET_NO_tail 327
#define APPLET_NO_tar 328
#define APPLET_NO_taskset 329
#define APPLET_NO_tc 330
#define APPLET_NO_tcpsvd 331
#define APPLET_NO_tee 332
#define APPLET_NO_telnet 333
#define APPLET_NO_telnetd 334
#define APPLET_NO_test 335
#define APPLET_NO_tftp 336
#define APPLET_NO_tftpd 337
#define APPLET_NO_time 338
#define APPLET_NO_timeout 339
#define APPLET_NO_top 340
#define APPLET_NO_touch 341
#define APPLET_NO_tr 342
#define APPLET_NO_traceroute 343
#define APPLET_NO_traceroute6 344
#define APPLET_NO_true 345
#define APPLET_NO_truncate 346
#define APPLET_NO_ts 347
#define APPLET_NO_tty 348
#define APPLET_NO_ttysize 349
#define APPLET_NO_tunctl 350
#define APPLET_NO_ubiattach 351
#define APPLET_NO_ubidetach 352
#define APPLET_NO_ubimkvol 353
#define APPLET_NO_ubirename 354
#define APPLET_NO_ubirmvol 355
#define APPLET_NO_ubirsvol 356
#define APPLET_NO_ubiupdatevol 357
#define APPLET_NO_udhcpc 358
#define APPLET_NO_udhcpc6 359
#define APPLET_NO_udhcpd 360
#define APPLET_NO_udpsvd 361
#define APPLET_NO_uevent 362
#define APPLET_NO_umount 363
#define APPLET_NO_uname 364
#define APPLET_NO_unexpand 365
#define APPLET_NO_uniq 366
#define APPLET_NO_unix2dos 367
#define APPLET_NO_unlink 368
#define APPLET_NO_unlzma 369
#define APPLET_NO_unshare 370
#define APPLET_NO_unxz 371
#define APPLET_NO_unzip 372
#define APPLET_NO_uptime 373
#define APPLET_NO_users 374
#define APPLET_NO_usleep 375
#define APPLET_NO_uudecode 376
#define APPLET_NO_uuencode 377
#define APPLET_NO_vconfig 378
#define APPLET_NO_vi 379
#define APPLET_NO_vlock 380
#define APPLET_NO_volname 381
#define APPLET_NO_w 382
#define APPLET_NO_wall 383
#define APPLET_NO_watch 384
#define APPLET_NO_watchdog 385
#define APPLET_NO_wc 386
#define APPLET_NO_wget 387
#define APPLET_NO_which 388
#define APPLET_NO_who 389
#define APPLET_NO_whoami 390
#define APPLET_NO_whois 391
#define APPLET_NO_xargs 392
#define APPLET_NO_xxd 393
#define APPLET_NO_xz 394
#define APPLET_NO_xzcat 395
#define APPLET_NO_yes 396
#define APPLET_NO_zcat 397
#define APPLET_NO_zcip 398

#ifndef SKIP_applet_main
int (*const applet_main[])(int argc, char **argv) = {
test_main,
test_main,
acpid_main,
add_remove_shell_main,
addgroup_main,
adduser_main,
adjtimex_main,
uname_main,
arp_main,
arping_main,
ascii_main,
ash_main,
awk_main,
baseNUM_main,
baseNUM_main,
basename_main,
bc_main,
beep_main,
blkdiscard_main,
blkid_main,
blockdev_main,
bootchartd_main,
brctl_main,
bunzip2_main,
bunzip2_main,
bzip2_main,
cal_main,
cat_main,
chat_main,
chattr_main,
chgrp_main,
chmod_main,
chown_main,
chpasswd_main,
chpst_main,
chroot_main,
chrt_main,
chvt_main,
cksum_main,
clear_main,
cmp_main,
comm_main,
conspy_main,
cp_main,
cpio_main,
cksum_main,
crond_main,
crontab_main,
cryptpw_main,
cttyhack_main,
cut_main,
date_main,
dc_main,
dd_main,
deallocvt_main,
deluser_main,
deluser_main,
modprobe_main,
devmem_main,
df_main,
dhcprelay_main,
diff_main,
dirname_main,
dmesg_main,
dnsd_main,
hostname_main,
dos2unix_main,
dpkg_main,
dpkg_deb_main,
du_main,
dumpkmap_main,
dumpleases_main,
echo_main,
ed_main,
grep_main,
eject_main,
env_main,
chpst_main,
chpst_main,
ether_wake_main,
expand_main,
expr_main,
factor_main,
fakeidentd_main,
fallocate_main,
false_main,
fatattr_main,
fbset_main,
fbsplash_main,
freeramdisk_main,
fdformat_main,
fdisk_main,
fgconsole_main,
grep_main,
find_main,
findfs_main,
flock_main,
fold_main,
free_main,
freeramdisk_main,
fsck_main,
fsck_minix_main,
fsfreeze_main,
fstrim_main,
fsync_main,
ftpd_main,
ftpgetput_main,
ftpgetput_main,
fuser_main,
getopt_main,
getty_main,
grep_main,
id_main,
gunzip_main,
gzip_main,
halt_main,
hexdump_main,
hdparm_main,
head_main,
hexdump_main,
hexedit_main,
hostid_main,
hostname_main,
httpd_main,
hush_main,
hwclock_main,
i2cdetect_main,
i2cdump_main,
i2cget_main,
i2cset_main,
i2ctransfer_main,
id_main,
ifconfig_main,
ifupdown_main,
ifenslave_main,
ifplugd_main,
ifupdown_main,
inetd_main,
init_main,
modprobe_main,
install_main,
ionice_main,
iostat_main,
ip_main,
ipaddr_main,
ipcalc_main,
ipcrm_main,
ipcs_main,
iplink_main,
ipneigh_main,
iproute_main,
iprule_main,
iptunnel_main,
kbd_mode_main,
kill_main,
kill_main,
kill_main,
klogd_main,
last_main,
less_main,
link_main,
setarch_main,
setarch_main,
init_main,
ln_main,
loadfont_main,
loadkmap_main,
logger_main,
login_main,
logname_main,
logread_main,
losetup_main,
lpd_main,
lpqr_main,
lpqr_main,
ls_main,
lsattr_main,
lsmod_main,
lsof_main,
lspci_main,
lsscsi_main,
lsusb_main,
unlzma_main,
unlzma_main,
lzop_main,
makedevs_main,
makemime_main,
man_main,
md5_sha1_sum_main,
mdev_main,
mesg_main,
microcom_main,
scripted_main,
mkdir_main,
mkfs_vfat_main,
mkfs_ext2_main,
mkfifo_main,
mkfs_ext2_main,
mkfs_minix_main,
mkfs_vfat_main,
mknod_main,
cryptpw_main,
mkswap_main,
mktemp_main,
modinfo_main,
modprobe_main,
more_main,
mount_main,
mountpoint_main,
mpstat_main,
mt_main,
mv_main,
nameif_main,
nandwrite_main,
nandwrite_main,
nbdclient_main,
nc_main,
netstat_main,
nice_main,
nl_main,
nmeter_main,
nohup_main,
scripted_main,
nproc_main,
nsenter_main,
nslookup_main,
ntpd_main,
od_main,
openvt_main,
partprobe_main,
passwd_main,
paste_main,
patch_main,
pgrep_main,
pidof_main,
ping_main,
ping6_main,
pipe_progress_main,
pivot_root_main,
pgrep_main,
pmap_main,
popmaildir_main,
halt_main,
powertop_main,
printenv_main,
printf_main,
ps_main,
pscan_main,
pstree_main,
pwd_main,
pwdx_main,
raidautorun_main,
rdate_main,
rdev_main,
readahead_main,
readlink_main,
readprofile_main,
realpath_main,
halt_main,
reformime_main,
add_remove_shell_main,
renice_main,
reset_main,
resize_main,
resume_main,
rev_main,
rm_main,
rmdir_main,
modprobe_main,
route_main,
rpm_main,
rpm2cpio_main,
rtcwake_main,
switch_root_main,
run_parts_main,
runlevel_main,
runsv_main,
runsvdir_main,
rx_main,
script_main,
scriptreplay_main,
sed_main,
sendmail_main,
seq_main,
setarch_main,
setconsole_main,
setfattr_main,
setfont_main,
setkeycodes_main,
setlogcons_main,
setpriv_main,
setserial_main,
setsid_main,
chpst_main,
ash_main,
md5_sha1_sum_main,
md5_sha1_sum_main,
md5_sha1_sum_main,
md5_sha1_sum_main,
showkey_main,
shred_main,
shuf_main,
slattach_main,
sleep_main,
smemcap_main,
chpst_main,
sort_main,
split_main,
ssl_client_main,
start_stop_daemon_main,
stat_main,
strings_main,
stty_main,
su_main,
sulogin_main,
sum_main,
sv_main,
svc_main,
svlogd_main,
svok_main,
swap_on_off_main,
swap_on_off_main,
switch_root_main,
sync_main,
sysctl_main,
syslogd_main,
tac_main,
tail_main,
tar_main,
taskset_main,
tc_main,
tcpudpsvd_main,
tee_main,
telnet_main,
telnetd_main,
test_main,
tftp_main,
tftpd_main,
time_main,
timeout_main,
top_main,
touch_main,
tr_main,
traceroute_main,
traceroute6_main,
true_main,
truncate_main,
ts_main,
tty_main,
ttysize_main,
tunctl_main,
ubi_tools_main,
ubi_tools_main,
ubi_tools_main,
ubirename_main,
ubi_tools_main,
ubi_tools_main,
ubi_tools_main,
udhcpc_main,
udhcpc6_main,
udhcpd_main,
tcpudpsvd_main,
uevent_main,
umount_main,
uname_main,
expand_main,
uniq_main,
dos2unix_main,
unlink_main,
unlzma_main,
unshare_main,
unxz_main,
unzip_main,
uptime_main,
who_main,
usleep_main,
uudecode_main,
uuencode_main,
vconfig_main,
vi_main,
vlock_main,
volname_main,
who_main,
wall_main,
watch_main,
watchdog_main,
wc_main,
wget_main,
which_main,
who_main,
whoami_main,
whois_main,
xargs_main,
xxd_main,
unxz_main,
unxz_main,
yes_main,
gunzip_main,
zcip_main,
};
#endif

const uint8_t applet_suid[] ALIGN1 = {
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x80,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x40,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x02,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x40,
0x00,
0x00,
0x00,
0x00,
0x00,
0x20,
0x40,
0x01,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x08,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x40,
0x01,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x00,
0x82,
0x00,
0x00,
0x00,
0x00,
};

const uint8_t applet_install_loc[] ALIGN1 = {
0x33,
0x42,
0x44,
0x12,
0x42,
0x13,
0x13,
0x31,
0x33,
0x23,
0x22,
0x34,
0x33,
0x13,
0x14,
0x11,
0x41,
0x43,
0x33,
0x33,
0x33,
0x11,
0x31,
0x34,
0x13,
0x13,
0x13,
0x43,
0x24,
0x12,
0x34,
0x13,
0x14,
0x33,
0x33,
0x31,
0x11,
0x31,
0x33,
0x43,
0x33,
0x43,
0x13,
0x41,
0x12,
0x24,
0x13,
0x23,
0x33,
0x23,
0x22,
0x24,
0x41,
0x33,
0x13,
0x12,
0x13,
0x21,
0x23,
0x33,
0x33,
0x41,
0x21,
0x44,
0x44,
0x34,
0x22,
0x42,
0x42,
0x22,
0x13,
0x21,
0x12,
0x33,
0x22,
0x22,
0x12,
0x31,
0x24,
0x33,
0x11,
0x01,
0x41,
0x32,
0x31,
0x22,
0x34,
0x13,
0x21,
0x33,
0x33,
0x33,
0x21,
0x31,
0x23,
0x33,
0x14,
0x22,
0x23,
0x22,
0x31,
0x12,
0x22,
0x11,
0x11,
0x11,
0x42,
0x44,
0x13,
0x31,
0x33,
0x34,
0x33,
0x34,
0x43,
0x33,
0x33,
0x11,
0x11,
0x32,
0x43,
0x42,
0x31,
0x31,
0x13,
0x23,
0x44,
0x34,
0x34,
0x12,
0x34,
0x33,
0x11,
0x11,
0x22,
0x31,
0x24,
0x21,
0x33,
0x33,
0x11,
0x34,
0x21,
0x43,
0x43,
0x11,
0x33,
0x31,
0x33,
0x33,
0x33,
0x12,
0x33,
0x33,
0x23,
0x31,
0x11,
0x32,
0x33,
0x34,
0x22,
0x12,
0x22,
0x33,
0x31,
0x32,
0x33,
0x34,
0x43,
0x33,
0x13,
0x33,
0x13,
0x33,
0x33,
0x42,
0x44,
0x44,
0x44,
0x32,
0x34,
0x12,
0x31,
0x33,
0x33,
0x33,
0x33,
0x13,
0x33,
0x12,
0x33,
0x33,
0x21,
0x33,
0x33,
0x33,
0x33,
0x33,
0x13,
0x02,
};
